#!/usr/bin/env bash
# TLD Public MP — Linux installer (Steam Proton / native).
# Usage:
#   ./install_linux.sh
#   ./install_linux.sh /path/to/The\ Long\ Drive   (custom install path)
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SRC="$SCRIPT_DIR/files"

DEFAULTS=(
  "$HOME/.local/share/Steam/steamapps/common/The Long Drive Public"
  "$HOME/.local/share/Steam/steamapps/common/The Long Drive"
  "$HOME/.steam/steam/steamapps/common/The Long Drive Public"
  "$HOME/.steam/steam/steamapps/common/The Long Drive"
)

TARGET=""
if [ -n "$1" ]; then TARGET="$1"
else
  for p in "${DEFAULTS[@]}"; do
    [ -f "$p/TheLongDrive.exe" ] && TARGET="$p" && break
  done
fi

if [ -z "$TARGET" ] || [ ! -f "$TARGET/TheLongDrive.exe" ]; then
  echo "ERROR: could not find TLD install."
  echo "  Pass the install path as the first argument."
  exit 1
fi

echo "Installing into: $TARGET"

# Backup existing
if [ -e "$TARGET/winhttp.dll" ] || [ -d "$TARGET/BepInEx" ]; then
  STAMP="$(date +%Y%m%d_%H%M%S)"
  BACKUP="$TARGET/.TLDPublicMP_backup_$STAMP"
  echo "Existing BepInEx detected — backing up to $BACKUP"
  mkdir -p "$BACKUP"
  [ -e "$TARGET/winhttp.dll" ]            && cp     "$TARGET/winhttp.dll"           "$BACKUP/"
  [ -e "$TARGET/doorstop_config.ini" ]    && cp     "$TARGET/doorstop_config.ini"   "$BACKUP/"
  [ -e "$TARGET/.doorstop_version" ]      && cp     "$TARGET/.doorstop_version"     "$BACKUP/" 2>/dev/null
  [ -e "$TARGET/steam_appid.txt" ]        && cp     "$TARGET/steam_appid.txt"       "$BACKUP/"
  [ -d "$TARGET/BepInEx" ]                && cp -r  "$TARGET/BepInEx"               "$BACKUP/"
fi

echo "Copying BepInEx framework + plugins + patcher..."
cp "$SRC/winhttp.dll"          "$TARGET/"
cp "$SRC/doorstop_config.ini"  "$TARGET/"
cp "$SRC/.doorstop_version"    "$TARGET/" 2>/dev/null || true
cp "$SRC/steam_appid.txt"      "$TARGET/"

mkdir -p "$TARGET/BepInEx/core" "$TARGET/BepInEx/plugins" "$TARGET/BepInEx/patchers" "$TARGET/BepInEx/config"
cp -r "$SRC/BepInEx/core/"*     "$TARGET/BepInEx/core/"
cp    "$SRC/BepInEx/plugins/"*.dll "$TARGET/BepInEx/plugins/"
cp    "$SRC/BepInEx/patchers/"*.dll "$TARGET/BepInEx/patchers/"
# Configs only if not already present (preserve user customizations)
for cfg in "$SRC/BepInEx/config/"*.cfg; do
  base="$(basename "$cfg")"
  if [ ! -f "$TARGET/BepInEx/config/$base" ]; then
    cp "$cfg" "$TARGET/BepInEx/config/"
  fi
done

cat <<EOF

===============================================================
TLD Public MP v1.1 installed.

Launch The Long Drive (public branch) via Steam normally.
The Multiplayer button should now appear on the main menu.

Auto-update is ON. The first launch will check
  https://raw.githubusercontent.com/Reedo22/The-Long-Drive-Fixes/main/public-mp.txt
and stage any newer plugin versions. The NEXT launch applies them.

Bundled plugins:
  TLDMPUnlock     — re-enables the MP button (hidden in stock public)
  TLDPubMPPatch   — ForceReliableSends + ForceMultiFlag for stable sync
  TLDPubDevMode   — enables dev menu (CapsLock = fly, F4/F8/F3/End/0/\`)
  TLDPubMPDiag    — packet diagnostic (disabled by default)
  TLDDirectMP     — direct-connect fallback (Mode=Off by default)
  TLDPubMPUpdater — patcher; checks github manifest, swaps .dll.update

Logs: $TARGET/BepInEx/LogOutput.log
Uninstall: ./uninstall_linux.sh
===============================================================
EOF
