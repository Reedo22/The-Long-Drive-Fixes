# TLD Public MP — Multiplayer & Performance Mod Pack

A collection of HarmonyX patches for **The Long Drive** (public branch on Steam) that fix multiplayer jitter,
reduce bandwidth, smooth remote car/item positions, and unlock the dev menu.

## Whats included

| Plugin               | Purpose                                                                            |
| -------------------- | ---------------------------------------------------------------------------------- |
| **TLDPubMPPatch**    | Main MP patches: driver authority, bandwidth dedupe, smoothing, claim-on-drive     |
| **TLDPubPerfPatch**  | FPS smoothing, outline cull, AudioInterior cache, rear-light dirty-check           |
| **TLDPubFullLog**    | JSONL state logger (snapshots/spawns/removes) — for diagnostics                    |
| **TLDPubMPCapture**  | Steam P2P packet capture to `BepInEx/replays/*.tldreplay`                          |
| **TLDPubLoopback**   | File-based bridge for testing two TLD instances on one machine                     |
| **TLDPubFakeId**     | Override `SteamUser.GetSteamID()` so two instances appear as different users       |
| **TLDPubSpawner**    | F2 in-game IMGUI overlay to spawn items/buildings (only when dev menu available)   |
| **TLDPubMPDiag**     | Lightweight network diagnostic counters                                            |
| **TLDPubDevMode**    | Re-enables dev menu                                                                |
| **TLDMPUnlock**      | Unlocks the multiplayer button on the main menu                                    |
| **TLDDirectMP**      | Direct-connect helper                                                              |

## Requirements

- The Long Drive (public branch) on Steam
- BepInEx 5.4.x already installed (this pack assumes BepInEx is in place)

## Install

1. Extract this zip
2. Copy the contents of `files/` into your TLD install directory (the one with `TheLongDrive.exe`)
   - On Linux/Proton: `~/.local/share/Steam/steamapps/common/The Long Drive Public/`
3. Launch the game once and quit so configs are generated
4. Open `BepInEx/config/com.reedo.tld.pubmppatch.cfg` to tweak settings

## Whats new in v2.0 (MPPatch 2.9.0)

- **Exit-snap fix** (`ClaimDrivenCars`): when you enter a car as a client we automatically claim its
  `tosaveitemscript`, so YOUR sim broadcasts position to the host. The host stops broadcasting back
  (game already gates on `claimed`). When you exit, host and client agree on where the car is, so no snap.
- **Remote item smoothing** (`SmoothRemoteItems`): the lerp window that already smoothed cars now also
  applies to loose items. Held / picked-up / slotted items are excluded.
- All previous v2.8 work: driver authority, bandwidth dedupes (~13x outbound reduction), tank rate limit, smooth-remote-cars.

## Config knobs of interest (`com.reedo.tld.pubmppatch.cfg`)

```
[Multiplayer]
ForceReliableSends = false   # leave false unless both ends same branch + observed loss
DriverAuthority = true       # don't let echoed inputs overwrite local driver
SyncBodyPush = true          # broadcast body-collision pushes
ClaimDrivenCars = true       # NEW — fixes exit-snap

[Smoothing]
SmoothRemoteCars = true
SmoothRemoteItems = true     # NEW
SmoothDurationMs = 250
SmoothMaxJumpMeters = 30
```

## Issues / contributions

Bug reports welcome. Source for `TLDPubMPPatch` is in `src/`; other plugins ship as binaries from local builds.

## License

Personal use. Use at your own risk. No warranty.
